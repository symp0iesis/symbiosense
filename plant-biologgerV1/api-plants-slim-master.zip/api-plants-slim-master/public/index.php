<?php

    use Psr\Http\Message\ResponseInterface as Response;
    use Psr\Http\Message\ServerRequestInterface as Request;
    use Slim\Factory\AppFactory;

    header('Access-Control-Allow-Origin: *');

    require __DIR__ . '/../vendor/autoload.php';

    $app = AppFactory::create();

    $app->addBodyParsingMiddleware();
    $app->addRoutingMiddleware();

    $errorMiddleware = $app->addErrorMiddleware(true, true, true);

    // Inclui o arquivo de rotas para dados
    require "../app/routes/data.php";
    
    $app->get('/', function (Request $request, Response $response, $args) {
        $response->getBody()->write("<h1>PLANTS API RUNNING!!</h1>");
        return $response;
    });

    // Executa Aplicação
    $app->run();