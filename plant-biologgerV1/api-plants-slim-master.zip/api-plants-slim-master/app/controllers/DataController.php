<?php
    
    namespace app\controllers;
   
    use Psr\Http\Message\ResponseInterface as Response;
    use Psr\Http\Message\ServerRequestInterface as Request;

    use app\database\models\Data;

    class DataController {

        private $data;

        public function __construct() {
            $this->data = new Data();
        }

        public function index(Request $request, Response $response, $args) {

            $data = $this->data->all();
            $response->getBody()->write(json_encode($data));
            return $response;
        }

        public function limit(Request $request, Response $response, $args) {

            $data = $this->data->select_limit($args['limit']);
            $response->getBody()->write(json_encode($data));
            return $response;
        }

        public function set(Request $request, Response $response, $args) {

            $data = $this->data->create(array(
                'date' => $this->data->getDateTime(), 
                'sensor' => $args['sensor'],
                'pressure' => $args['press'],
                'humidity' => $args['humi'],
                'temperature' => $args['temp'],
                'gas' => $args['gas'],
            ));

            $response->getBody()->write(json_encode($data));
            return $response;
        }

        public function create(Request $request, Response $response, $args) {

            $input = $request->getParsedBody();

            $data = $this->data->create(array(
                'date' => $this->data->getDateTime(), 
                'sensor' => $input['sensor'],
                'pressure' => $input['press'],
                'humidity' => $input['humi'],
                'temperature' => $input['temp'],
                'gas' => $input['gas'],
            ));

            $response->getBody()->write(json_encode($data));
            return $response;
        }
    }