<?php
    
    define('HOST', 'localhost');
    define('DB', 'slim');
    define('USER', 'root');
    define('PASSWORD', 'Gil.Eduardo12');