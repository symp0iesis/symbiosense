<?php

    namespace app\traits;

    trait Read {

        public function all($returnAll = true) {

            try {

                $query = $this->connection->query("SELECT * FROM {$this->table}");
                return $returnAll ? $query->fetchAll() : $query->fetch();

            } catch(PDOException $e) {
                var_dump($e->getMessage());
            }
        }

        public function select_limit($limit=1, $returnAll = true) {

            try {
                $query = $this->connection->query("SELECT * FROM {$this->table} ORDER BY id DESC LIMIT ".$limit);
                return $returnAll ? $query->fetchAll() : $query->fetch();
                
            } catch(PDOException $e) {
                var_dump($e->getMessage());
            }
        }

        public function find($field, $value, $returnAll = true) {

            try {

                $prepared = $this->connection->prepare("SELECT * FROM {$this->table} WHERE {$field} = :{$field}");
                $prepared->bindValue(":{$field}", $value);
                $prepared->execute();
                return $returnAll ? $prepared->fetchAll() : $prepared->fetch();

            } catch(PDOException $e) {
                var_dump($e->getMessage());
            }
        }
    }