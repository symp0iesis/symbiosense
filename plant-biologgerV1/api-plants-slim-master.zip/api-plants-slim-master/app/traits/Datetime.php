<?php

    namespace app\traits;

    trait Datetime {

        public function getDateTime() {

            try {
                $dt =  getdate();
                $ret = $dt['year']."-".$dt['mon']."-". $dt['mday']." ". $dt['hours'].":".$dt['minutes'].":".$dt['seconds'];
                return $ret;

            } catch(PDOException $e) {
                var_dump($e->getMessage());
            }
        }
    }