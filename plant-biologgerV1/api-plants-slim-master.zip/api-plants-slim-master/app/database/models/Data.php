<?php

    namespace app\database\models;  

    class Data extends Model {

        protected $table = 'dados';
    }