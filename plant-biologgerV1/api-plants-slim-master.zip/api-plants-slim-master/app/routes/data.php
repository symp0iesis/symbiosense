<?php

    use app\controllers\MessageController;

    $app->get('/data', 'app\controllers\DataController:index');
    $app->get('/data/limit/{limit}', 'app\controllers\DataController:limit');
    $app->post('/data/create', 'app\controllers\DataController:create');
    